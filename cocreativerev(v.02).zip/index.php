<?php

// session_start();

// if(!isset($_SESSION["login"])){
//     header("Location: login.php");
//     exit;
// }

// if(isset($_POST['add'])){
//     header("Location: adduser.php");
//     exit;
// }
require'function.php';

// $username = query("SELECT * FROM user");

// if(isset($_POST["cari"])){
//     $username = cari($_POST["keyword"]);
// }

$g = query("SELECT * FROM logo ORDER BY id DESC LIMIT 1");

$gambar = query("SELECT * FROM slider");
// var_dump($gambar);
$gambar2 = query("SELECT * FROM gallery");
// var_dump($gambar2);
?>

<!DOCTYPE html>
<!--[if lt IE 7]>      <html lang="en" class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html lang="en" class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html lang="en" class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
    <head>
    	<!-- meta character set -->
        <meta charset="utf-8">
		<!-- Always force latest IE rendering engine or request Chrome Frame -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>CoCreative</title>		
		<!-- Meta Description -->
        <meta name="description" content="Blue One Page Creative HTML5 Template">
        <meta name="keywords" content="one page, single page, onepage, responsive, parallax, creative, business, html5, css3, css3 animation">
        <meta name="author" content="Muhammad Morshed">
		
		<!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
		
		<!-- CSS
		================================================== -->
		
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
		
		<!-- Fontawesome Icon font -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
		<!-- bootstrap.min -->
        <link rel="stylesheet" href="css/jquery.fancybox.css">
		<!-- bootstrap.min -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- bootstrap.min -->
        <link rel="stylesheet" href="css/owl.carousel.css">
		<!-- bootstrap.min -->
        <link rel="stylesheet" href="css/slit-slider.css">
		<!-- bootstrap.min -->
        <link rel="stylesheet" href="css/animate.css">
		<!-- Main Stylesheet -->
        <link rel="stylesheet" href="css/main.css">

		<!-- Modernizer Script for old Browsers -->
        <script src="js/modernizr-2.6.2.min.js"></script>
			<style>
			.bg-img-1 {
				background-image: url(assets/img/slider/<?= $gambar[0]['gambar'];?>);
			}
			.bg-img-2 {
				background-image: url(assets/img/slider/<?= $gambar[1]['gambar'];?>);
			}
			.bg-img-3 {
				background-image: url(assets/img/slider/<?= $gambar[2]['gambar'];?>);
			}
			</style>
    </head>
	
    <body id="body">
<!-- Back to top button -->
<a id="back2Top" title="Back to top" href="#">&#10148;</a>
		<!-- preloader -->
		<div id="preloader">
            <div class="loder-box">
            	<div class="battery"></div>
            </div>
		</div>
		<!-- end preloader -->

        
        <!--  Fixed Navigation
        ==================================== -->
        <header id="navigation" class="navbar-inverse navbar-fixed-top animated-header">
            <div class="container">
                <div class="navbar-header">
                    <!-- responsive nav button -->
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
                    </button>
					<!-- /responsive nav button -->
					
					<!-- logo -->
					<a class="navbar-brand" href="index-admin.php"><img src="./assets/img/<?= $g[0]['gambar']?>" id="logo" width="50"></a> 
					<!-- <h1 class="navbar-brand"> -->
						<!-- <a href="#body">Co Creative</a> -->
					<!-- </h1> -->
					<!-- /logo -->
                </div>

				<!-- main nav -->
                <nav class="collapse navbar-collapse navbar-right" role="navigation">
                    <ul id="nav" class="nav navbar-nav">
                        <li><a href="#body">Home</a></li>
                        <li><a href="#service">Our Product</a></li>
                        <li><a href="#portfolio">What’s on Co Creative</a></li>
                        <li><a href="#OurSpace">Our Space</a></li>
                        <li><a href="#price">Membership Price</a></li>
                        <li><a href="#contact">Contact</a></li>
                        <a class="btnbook btn" href="https://wa.me/6281222771703"role="button">Book Now</a>
                    </ul>
                  
                </nav>
				<!-- /main nav -->
				
            </div>
        </header>
        <!--
        End Fixed Navigation
        ==================================== -->
		
		<main class="site-content" role="main">
		
        <!--
        Home Slider
        ==================================== -->
		
		<section id="home-slider">
            <div id="slider" class="sl-slider-wrapper">

				<div class="sl-slider">
				
					<div class="sl-slide" data-orientation="horizontal" data-slice1-rotation="-25" data-slice2-rotation="-25" data-slice1-scale="2" data-slice2-scale="2">

						<div class="bg-img bg-img-1"></div>

						<div class="slide-caption">
                            <div class="caption-content">
                                <h2 class="animated fadeInDown CoCreativewarna"><?= $gambar[0]['judul'];?></h2>
                                <span class="animated fadeInDown p-slider"><?= $gambar[0]['paragraf'];?></span>
                                <a href="#" target="_blank" class="btn btn-blue btn-effect">Learn More</a>
                            </div>
                        </div>
						
					</div>
					
					<div class="sl-slide" data-orientation="vertical" data-slice1-rotation="10" data-slice2-rotation="-15" data-slice1-scale="1.5" data-slice2-scale="1.5">
					
						<div class="bg-img bg-img-2"></div>
						<div class="slide-caption">
                            <div class="caption-content">
								<h2 class="animated fadeInDown CoCreativewarna"><?= $gambar[1]['judul'];?></h2>
                                <span class="animated fadeInDown p-slider"><?= $gambar[1]['paragraf'];?></span>
                                <a href="#event" class="btn btn-blue btn-effect">Find us</a>
                            </div>
                        </div>
						
					</div>
					
					<div class="sl-slide" data-orientation="horizontal" data-slice1-rotation="3" data-slice2-rotation="3" data-slice1-scale="2" data-slice2-scale="1">
						
						<div class="bg-img bg-img-3"></div>
						<div class="slide-caption">
                            <div class="caption-content">
								<h2 class="animated fadeInDown CoCreativewarna"><?= $gambar[2]['judul'];?></h2>
                                <span class="animated fadeInDown p-slider"><?= $gambar[2]['paragraf'];?></span>
                                <a href="https://wa.me/6281222771703" class="btn btn-blue btn-effect">BOOK NOW</a>
                            </div>
                        </div>

					</div>

				</div><!-- /sl-slider -->

                <!-- 
                <nav id="nav-arrows" class="nav-arrows">
                    <span class="nav-arrow-prev">Previous</span>
                    <span class="nav-arrow-next">Next</span>
                </nav>
                -->
                
                <nav id="nav-arrows" class="nav-arrows hidden-xs hidden-sm visible-md visible-lg">
                    <a href="javascript:;" class="sl-prev">
                        <i class="fa fa-angle-left fa-3x"></i>
                    </a>
                    <a href="javascript:;" class="sl-next">
                        <i class="fa fa-angle-right fa-3x"></i>
                    </a>
                </nav>
                

				<nav id="nav-dots" class="nav-dots visible-xs visible-sm hidden-md hidden-lg">
					<span class="nav-dot-current"></span>
					<span></span>
					<span></span>
				</nav>

			</div><!-- /slider-wrapper -->
		</section>
		
        <!--
        End Home SliderEnd
        ==================================== -->
		
			<!-- about section -->
			<section id="about" >
				<div class="container">
					<div class="row">
						<div class="col-md-4 col-xs-12 wow animated fadeInLeft">
							<div class="recent-works">
									<h3>About Us</h3>
								<div id="works">
									<div class="work-item">
										<p>Have a role to be best business incubator in the city of Bandung. Brige the creativity thought innovation for freelancers and entrepreneurs by providing a comfortable and inspiring workspace with the Garden House concept....</p>

									</div>
									<div class="work-item">
										<p>Co Creative becomes a friendly work ecosystem, where interaction between individuals or teams in cooperation  sharing creative ideas and innovation.</p>
									</div>
									
								</div>
							</div>
						</div>
						<div class="col-md-7 col-xs-12 col-md-offset-1 wow animated fadeInRight">
							<div class="welcome-block">	
								 <h3>Our Mission</h3>						
						     	 <div class="message-body">
						       		<p>Be the Leader as Coworking in business development and innovation.Provide all facility on environment in which all tenants can explore creative, productive ideas at work and the opportunity to develop wider business conectivity.</p>
						     	 </div>
						       	<a href="#" class="btn btn-border btn-effect pull-right">Read More</a>
						    </div>
						</div>
					</div>
				</div>
			</section>
			<!-- end about section -->
			
			
			<!-- Service section -->
			<section id="service">
				<div class="container">
					<div class="row">
					
						<div class="sec-title text-center">
							<h2 class="wow animated bounceInLeft">Our Product</h2>
							<p class="wow animated bounceInRight">What can you get ?</p>
						</div>
						
						<div class="col-md-3 col-sm-6 col-xs-12 text-center wow animated zoomIn">
							<div class="service-item">
								<div class="service-icon">
									<i class="fa fa-laptop fa-3x"></i>
								</div>
								<h3>Coworking Space</h3>
								<p>Provide Space for individuals or team with the best facility for working on idea and being productive. </p>
							</div>
						</div>
					
						<div class="col-md-3 col-sm-6 col-xs-12 text-center wow animated zoomIn" data-wow-delay="0.3s">
							<div class="service-item">
								<div class="service-icon">
									<i class="fa fa-calendar-check fa-3x"></i>
								</div>
								<h3>Event Space</h3>
								<p>Providing best place for supporting any of event with big capacity.</p>
							</div>
						</div>
					
						<div class="col-md-3 col-sm-6 col-xs-12 text-center wow animated zoomIn" data-wow-delay="0.6s">
							<div class="service-item">
								<div class="service-icon">
									<i class="fa fa-clock-o fa-3x"></i>
								</div>
								<h3>Virtual Office</h3>
								<p>Facilitating Startup to own Virtual Office.</p>
							</div>
						</div>
					
						<div class="col-md-3 col-sm-6 col-xs-12 text-center wow animated zoomIn" data-wow-delay="0.9s">
							<div class="service-item">
								<div class="service-icon">
									<i class="fa fa-building fa-3x"></i>
								</div>
								
								<h3>Office Space</h3>
								<p>Offering Rent Offices for startup companies that require physical offices for their employees.</p>							
							</div>
						</div>
						<div class="col-md-3 col-sm-6 col-xs-12 text-center wow animated zoomIn" data-wow-delay="0.9s">
							<div class="service-item">
								<div class="service-icon">
									<i class="fa fa-coffee fa-3x"></i>
								</div>
								<h3>Coffee Shop</h3>
								<p>provide food & beverage for the needs of the coworkers when working.</p>							
							</div>
						</div>

						<div class="col-md-3 col-sm-6 col-xs-12 text-center wow animated zoomIn" data-wow-delay="0.9s">
							<div class="service-item">
								<div class="service-icon">
									<i class="fa fa-chalkboard-teacher fa-3x"></i>
								</div>
								<h3>Meeting Room</h3>
								<p>Providing space for group customers who want to conduct meetings with small groups using various meeting facilities.</p>							
							</div>
						</div>
						
					</div>
				</div>
			</section>
			<!-- end Service section -->
			
			<!-- portfolio section -->
			<section id="portfolio" class="portofolio">
				<div class="container">
					<div class="row">
					
						<div class="sec-title text-center wow animated fadeInDown">
							<h2>What’s on Co Creative ?</h2>
							<p>You Can Enjoy</p>
						</div>

						<div class="col-md-3 col-sm-6 col-xs-12 text-center wow animated zoomIn">
							<div class="service-item">
								<div class="service-icon">
									<i class="fa fa-wifi fa-3x"></i>
								</div>
								<h3>High Speed Internet</h3>
							</div>
						</div>
					
						<div class="col-md-3 col-sm-6 col-xs-12 text-center wow animated zoomIn" data-wow-delay="0.3s">
							<div class="service-item">
								<div class="service-icon">
									<i class="fa fa-couch fa-3x"></i>
								</div>
								<h3>Convenient Location</h3>
							</div>
						</div>
					
						<div class="col-md-3 col-sm-6 col-xs-12 text-center wow animated zoomIn" data-wow-delay="0.6s">
							<div class="service-item">
								<div class="service-icon">
									<i class="fa fa-chart-line fa-3x"></i>
								</div>
								<h3>Bussines Forum to Grow Your Start Up</h3>
							</div>
						</div>
					
						<div class="col-md-3 col-sm-6 col-xs-12 text-center wow animated zoomIn" data-wow-delay="0.9s">
							<div class="service-item">
								<div class="service-icon">
									<i class="fa fa-clock fa-3x"></i>
								</div>
								<h3>Flexible Schedule</h3>						
							</div>
						</div>
					</div>
				
					<div class="row">
						<div class="col-md-3 col-sm-6 col-xs-12 text-center wow animated zoomIn" data-wow-delay="0.9s">
							<div class="service-item">
								<div class="service-icon">
									<i class="fa fa-users fa-3x"></i>
								</div>
								<h3>Member Network Throught Colaboration</h3>						
							</div>
						</div>

						<div class="col-md-3 col-sm-6 col-xs-12 text-center wow animated zoomIn" data-wow-delay="0.9s">
							<div class="service-item">
								<div class="service-icon">
									<i class="fa fa-cogs fa-3x"></i>
								</div>
								<h3>Creative event & workshop Business</h3>						
							</div>
						</div>

						<div class="col-md-3 col-sm-6 col-xs-12 text-center wow animated zoomIn" data-wow-delay="0.9s">
							<div class="service-item">
								<div class="service-icon">
									<i class="fa fa-smile fa-3x"></i>
								</div>
								<h3>Best Facilities</h3>						
							</div>
						</div>

						<div class="col-md-3 col-sm-6 col-xs-12 text-center wow animated zoomIn" data-wow-delay="0.9s">
							<div class="service-item">
								<div class="service-icon">
									<i class="fa fa-utensils fa-3x"></i>
								</div>
								<h3>Food & Beverages</h3>						
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- end portfolio section -->
			
			<!--  -->
			 <!-- <section id="testimonials" class="parallax">
				<div class="overlay">
					<div class="container">
						<div class="row">
						
							<div class="sec-title text-center white wow animated fadeInDown">
								<h2>EVENT SPACE</h2>
							</div>
							
							<div id="testimonial" class=" wow animated fadeInUp">
								<div class="testimonial-item text-center">
									
									<div class="clearfix">
										<span>Event</span>
										<p>Need event space for Create great Workshop or Mini Class on your passion ? or do you want to Launch your product and get the best impression on it ?Maybe you want to celebrate something with people ?with Co Creative let’s make any event memorable..</p>
									</div>
									<a href="https://wa.me/6281222771703" class="btn btn-blue btn-effect">Book Now</a>
								
							</div>
						
						</div>
					</div>
				</div>
			</section>  -->



			<section id="event"> 
				<div class="overlay">
				<div class="container">
					<div class="row">
						<div class="sec-title text-center white wow animated fadeInDown">
							<h2>Event Space</h2>
						</div>
						<div id="events" class=" wow animated fadeInUp">
							<div class="events-item text-center">
								<div class="clearfix">
									<span>Create & Collab</span>
									<p>Need event space to Create great Workshop or Mini Class on your passion ? 
										or do you want to Launch your product and get the best impression on it ?
										 Maybe you want to celebrate something with people ? with <strong>Co Creative</strong> let’s make any event memorable..</p>
								</div>
								<a href="https://wa.me/6281222771703" class="btn btn-blue btn-effect">Book Now</a>
								
							</div>
							
						</div>
						

					</div>
					

				</div>
			</div>
		</section>
			<!--  -->
			<!-- Our Space section-->

			<section id="OurSpace">
				
				<div class="container">
					<div class="row">
					<!-- ---------------------------------------------------------------------->
					<!-- ----------------------- gallery display : parent --------------------->
					<!-- ---------------------------------------------------------------------->
						<div class="sec-title text-center wow animated fadeInDown">
							<h2>OUR SPACE</h2>
							<p></p>
						</div>
						<ul class="project-wrapper wow animated fadeInUp">
						<!-- ----------------------- gallery display : Co Working Space --------------------->
							<li class="portfolio-item">
								<img src="assets/img/gallery/<?= $gambar2[0]['gambar'];?>" class="img-responsive" alt="<?= $gambar2[0]['paragraf'];?>">
								<figcaption class="mask">
									<h3><?= $gambar2[0]['judul'];?></h3>
									<p><?= $gambar2[0]['ketjudul'];?></p>
								</figcaption>
								<ul class="external">
									<li><a class="fancybox" title="Araund The world" data-fancybox-group="coworking-space" href="assets/img/gallery/<?= $gambar2[0]['gambar'];?>">
									<i class="fa fa-search"></i></a></li>
									<li><a href=""><i class="fa fa-link"></i></a></li>
								</ul>
							</li>

						<!-- ----------------------- gallery display : Our Space --------------------->
							<li class="portfolio-item">
								<img src="assets/img/gallery/<?= $gambar2[1]['gambar'];?>" class="img-responsive" alt="<?= $gambar2[1]['paragraf'];?>">
								<figcaption class="mask">
									<h3><?= $gambar2[1]['judul'];?></h3>
									<p><?= $gambar2[1]['ketjudul'];?></p>
								</figcaption>
								<ul class="external">
									<li><a class="fancybox" title="Wall street" href="assets/img/gallery/<?= $gambar2[1]['gambar'];?>" data-fancybox-group="our-space" ><i class="fa fa-search"></i></a></li>
									<li><a href=""><i class="fa fa-link"></i></a></li>
								</ul>
							</li>

						<!-- ----------------------- gallery display : Event Space --------------------->
							<li class="portfolio-item">
								<img src="assets/img/gallery/<?= $gambar2[2]['gambar'];?>" class="img-responsive" alt="<?= $gambar2[2]['paragraf'];?>">
								<figcaption class="mask">
									<h3><?= $gambar2[2]['judul'];?></h3>
									<p><?= $gambar2[2]['ketjudul'];?></p>
								</figcaption>
								<ul class="external">
									<li><a class="fancybox" title="Wall street" href="assets/img/gallery/<?= $gambar2[2]['gambar'];?>" data-fancybox-group="event-space"><i class="fa fa-search"></i></a></li>
									<li><a href=""><i class="fa fa-link"></i></a></li>
								</ul>
							</li>

						<!-- ----------------------- gallery display : Meeting Room --------------------->
							<li class="portfolio-item">
								<img src="assets/img/gallery/<?= $gambar2[3]['gambar'];?>" class="img-responsive" alt="<?= $gambar2[3]['paragraf'];?>">
								<figcaption class="mask">
									<h3><?= $gambar2[3]['judul'];?></h3>
									<p><?= $gambar2[3]['ketjudul'];?></p>
								</figcaption>
								<ul class="external">
									<li><a class="fancybox" title="Wall street" href="assets/img/gallery/<?= $gambar2[3]['gambar'];?>" data-fancybox-group="meeting-room"><i class="fa fa-search"></i></a></li>
									<li><a href=""><i class="fa fa-link"></i></a></li>
								</ul>
							</li>

						<!-- ----------------------- gallery display : Amenities --------------------->
							<li class="portfolio-item">
								<img src="assets/img/gallery/<?= $gambar2[4]['gambar'];?>" class="img-responsive" alt="<?= $gambar2[4]['paragraf'];?>">
								<figcaption class="mask">
									<h3><?= $gambar2[4]['judul'];?></h3>
									<p><?= $gambar2[4]['ketjudul'];?></p>
								</figcaption>
								<ul class="external">
									<li><a class="fancybox" title="Wall street" href="assets/img/gallery/<?= $gambar2[4]['gambar'];?>" data-fancybox-group="amenities"><i class="fa fa-search"></i></a></li>
									<li><a href=""><i class="fa fa-link"></i></a></li>
								</ul>
							</li>

						<!-- ----------------------- gallery display : Office Space --------------------->
						<li class="portfolio-item">
								<img src="assets/img/gallery/<?= $gambar2[5]['gambar'];?>" class="img-responsive" alt="<?= $gambar2[5]['paragraf'];?>">
								<figcaption class="mask">
									<h3><?= $gambar2[5]['judul'];?></h3>
									<p><?= $gambar2[5]['ketjudul'];?></p>
								</figcaption>
								<ul class="external">
									<li><a class="fancybox" title="Wall street" href="assets/img/gallery/<?= $gambar2[5]['gambar'];?>" data-fancybox-group="Office Space"><i class="fa fa-search"></i></a></li>
									<li><a href=""><i class="fa fa-link"></i></a></li>
								</ul>
							</li>
					</ul>

					<!-- ---------------------------------------------------------------------->
					<!-- ----------------------- gallery display : kids --------------------->
					<!-- ---------------------------------------------------------------------->


					<!-- ----------------------- gallery display : Co Working Space --------------------->
						<ul style="display:none;" class="project-wrapper wow animated fadeInUp">							
							<li class="portfolio-item">
								<img src="img/aboutheader.jpg" class="img-responsive" alt="Low ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat">
								<figcaption class="mask">
									<h3>Coworking Space</h3>
									<p>Low Speed Internet Access,Free Flow Water,Convenience Space & Furniture </p>
								</figcaption>
								<ul class="external">
									<li><a class="fancybox" title="Low The world" data-fancybox-group="coworking-space" href="img/aboutheader.jpg">
									<i class="fa fa-search"></i></a></li>
									<li><a href=""><i class="fa fa-link"></i></a></li>
								</ul>
							</li>				

							<!-- ----------------------- gallery display : Our Space --------------------->
							<li class="portfolio-item">
								<img src="img/aboutheader.jpg" class="img-responsive" alt="Low ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat">
								<figcaption class="mask">
									<h3>Our Space</h3>
									<p>Low Speed Internet Access,Free Flow Water,Convenience Space & Furniture </p>
								</figcaption>
								<ul class="external">
									<li><a class="fancybox" title="Low The world" data-fancybox-group="our-space" href="img/aboutheader.jpg">
									<i class="fa fa-search"></i></a></li>
									<li><a href=""><i class="fa fa-link"></i></a></li>
								</ul>
							</li>		

							<!-- ----------------------- gallery display : Event Space --------------------->	
							<li class="portfolio-item">
								<img src="img/aboutheader.jpg" class="img-responsive" alt="Low ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat">
								<figcaption class="mask">
									<h3>Event Space</h3>
									<p>Low Speed Internet Access,Free Flow Water,Convenience Space & Furniture </p>
								</figcaption>
								<ul class="external">
									<li><a class="fancybox" title="Low The world" data-fancybox-group="event-space" href="img/aboutheader.jpg">
									<i class="fa fa-search"></i></a></li>
									<li><a href=""><i class="fa fa-link"></i></a></li>
								</ul>
							</li>
							
							<!-- ----------------------- gallery display : Meeting Room --------------------->
							<li class="portfolio-item">
								<img src="img/meetingroom_garden.jpg" class="img-responsive" alt="Lorem Ipsum is simply dummy text of the printing and typesetting ndustry. ">
								<figcaption class="mask">
									<h3>Event Space</h3>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting ndustry. </p>
								</figcaption>
								<ul class="external">
									<li><a class="fancybox" title="Wall street" href="img/meetingroom_garden.jpg" data-fancybox-group="meeting-room"><i class="fa fa-search"></i></a></li>
									<li><a href=""><i class="fa fa-link"></i></a></li>
								</ul>
							</li>

							<!-- ----------------------- gallery display : Amenities --------------------->
							<li class="portfolio-item">
								<img src="img/meetingroom_garden.jpg" class="img-responsive" alt="Lorem Ipsum is simply dummy text of the printing and typesetting ndustry. ">
								<figcaption class="mask">
									<h3>Amenities</h3>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting ndustry. </p>
								</figcaption>
								<ul class="external">
									<li><a class="fancybox" title="Wall street" href="img/gal_garden2.jpg" data-fancybox-group="amenities"><i class="fa fa-search"></i></a></li>
									<li><a href=""><i class="fa fa-link"></i></a></li>
								</ul>
							</li>

							<!-- ----------------------- gallery display : Office Space --------------------->
							<li class="portfolio-item">
								<img src="img/meetingroom_garden.jpg" class="img-responsive" alt="Lorem Ipsum is simply dummy text of the printing and typesetting ndustry. ">
								<figcaption class="mask">
									<h3>Office Space</h3>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting ndustry. </p>
								</figcaption>
								<ul class="external">
									<li><a class="fancybox" title="Wall street" href="img/gal_garden2.jpg" data-fancybox-group="Office Space"><i class="fa fa-search"></i></a></li>
									<li><a href=""><i class="fa fa-link"></i></a></li>
								</ul>
							</li>
							
						
						</ul>
						
					</div>
				</div>
			</section>

			<!-- price -->

			<div id="generic_price_table">   
<section id="price">
        <div class="container">
            <div class="row">
            	<div class="sec-title text-center wow animated fadeInDown">
							<h2>Membership & Price</h2>
							<p>Working Space</p>
						</div>
                <div class="col-md-12">
                    <!--PRICE HEADING START-->
                    <div class="price-heading clearfix">
                    </div>
                    <!--//PRICE HEADING END-->
                </div>
            </div>
        </div>
        <div class="container">
            
            <!--BLOCK ROW START-->
            <div class="row">
                <div class="col-md-3">
                
                	<!--PRICE CONTENT START-->
                    <div class="generic_content clearfix">
                        
                        <!--HEAD PRICE DETAIL START-->
                        <div class="generic_head_price clearfix">
                        
                            <!--HEAD CONTENT START-->
                            <div class="generic_head_content clearfix">
                            
                            	<!--HEAD START-->
                                <div class="head_bg"></div>
                                <div class="head">
                                    <span>Walk in 3 Hours</span>
                                </div>
                                <!--//HEAD END-->
                                
                            </div>
                            <!--//HEAD CONTENT END-->
                            
                            <!--PRICE START-->
                            <div class="generic_price_tag clearfix">	
                                <span class="price">
                                    <span class="sign">Rp.</span>
                                    <span class="currency">150</span>
									<span class="cent">.000</span>
									<br>
                                    <span class="month">/Hrs</span>
                                </span>
                            </div>
                            <!--//PRICE END-->
                            
                        </div>                            
                        <!--//HEAD PRICE DETAIL END-->
                        
                        <!--FEATURE LIST START-->
                        <div class="generic_feature_list">
                        	<ul>
                                <li><span>Free</span> high speed internet access</li>
                                <li><span>Individual</span> hot-seat in coworking space</li>
                                <li><span>Free</span> flow fresh water</li> 
                                <li><span></span> </li>
                                <li><span></span> </li>                         
                            </ul>
                        </div>
                        <!--//FEATURE LIST END-->
                        
                        <!--BUTTON START-->
                        <div class="generic_price_btn clearfix">
                        	<a class="" href="">Sign up</a>
                        </div>
                        <!--//BUTTON END-->
                        
                    </div>
                    <!--//PRICE CONTENT END-->
                        
                </div>
                
                <div class="col-md-3">
                
                	<!--PRICE CONTENT START-->
                    <div class="generic_content clearfix">
                        
                        <!--HEAD PRICE DETAIL START-->
                        <div class="generic_head_price clearfix">
                        
                            <!--HEAD CONTENT START-->
                            <div class="generic_head_content clearfix">
                            
                            	<!--HEAD START-->
                                <div class="head_bg"></div>
                                <div class="head">
                                    <span>Daily </span>
                                    <br/>

                                    <span> 12 Hours</span>
                                </div>
                                <!--//HEAD END-->
                                
                            </div>
                            <!--//HEAD CONTENT END-->
                            
                            <!--PRICE START-->
                            <div class="generic_price_tag clearfix">	
                                <span class="price">
                                    <span class="sign">Rp.</span>
                                    <span class="currency">145</span>
									<span class="cent">.000</span>
									<br>
                                    <span class="month">/Hrs</span>
                                </span>
                            </div>
                            <!--//PRICE END-->
                            
                        </div>                            
                        <!--//HEAD PRICE DETAIL END-->
                        
                        <!--FEATURE LIST START-->
                        <div class="generic_feature_list">
                        	<ul>
                                <li><span>12 Hours</span> access</li>
                                <li><span>Free</span> high speed internet access</li>
                                <li><span>Individual </span> hot-seat in coworking space</li> 
                                <li><span></span> </li>
                                <li><span></span> </li>   
                                                      
                            </ul>
                        </div>
                        <!--//FEATURE LIST END-->
                        
                        <!--BUTTON START-->
                        <div class="generic_price_btn clearfix">
                        	<a class="" href="">Sign up</a>
                        </div>
                        <!--//BUTTON END-->
                        
                    </div>
                    <!--//PRICE CONTENT END-->


                    <!--//PRICE CONTENT END-->
                        
                </div>
                <div class="col-md-3">
                
                	<!--PRICE CONTENT START-->
                    <div class="generic_content clearfix">
                        
                        <!--HEAD PRICE DETAIL START-->
                        <div class="generic_head_price clearfix">
                        
                            <!--HEAD CONTENT START-->
                            <div class="generic_head_content clearfix">
                            
                            	<!--HEAD START-->
                                <div class="head_bg"></div>
                                <div class="head">
                                    <span>Weekly Membership</span>
                                </div>
                                <!--//HEAD END-->
                                
                            </div>
                            <!--//HEAD CONTENT END-->
                            
                            <!--PRICE START-->
                            <div class="generic_price_tag clearfix">	
                                <span class="price">
                                    <span class="sign">Rp.</span>
                                    <span class="currency">1.250</span>
                                    <span class="cent">.000</span>
                                    <span class="month">/Week</span>
                                </span>
                            </div>
                            <!--//PRICE END-->
                            
                        </div>                            
                        <!--//HEAD PRICE DETAIL END-->
                        
                        <!--FEATURE LIST START-->
                        <div class="generic_feature_list">
                        	<ul>
                            	<li><span>Unlimited</span> access</li>
                                <li><span>Free</span> high speed internet access</li>
                                <li><span>Individual</span> hot-seat in coworking space</li>
                                <li><span>Free</span> flow fresh water</li>
                                <li><span>Member discount</span> for events & meeting rooms</li>
                            </ul>
                        </div>
                        <!--//FEATURE LIST END-->
                        
                        <!--BUTTON START-->
                        <div class="generic_price_btn clearfix">
                        	<a class="" href="">Sign up</a>
                        </div>
                        <!--//BUTTON END-->
                        
                    </div>
                    <!--//PRICE CONTENT END-->
                        
                </div>


                <div class="col-md-3">
                
                	<!--PRICE CONTENT START-->
                    <div class="generic_content clearfix">
                        
                        <!--HEAD PRICE DETAIL START-->
                        <div class="generic_head_price clearfix">
                        
                            <!--HEAD CONTENT START-->
                            <div class="generic_head_content clearfix">
                            
                            	<!--HEAD START-->
                                <div class="head_bg"></div>
                                <div class="head">
                                    <span>Monthly Membership</span>
                                </div>
                                <!--//HEAD END-->
                                
                            </div>
                            <!--//HEAD CONTENT END-->
                            
                            <!--PRICE START-->
                            <div class="generic_price_tag clearfix">	
                                <span class="price">
                                    <span class="sign">Rp.</span>
                                    <span class="currency">4.000</span>
                                    <span class="cent">.000</span>
                                    <span class="month">/Mon</span>
                                </span>
                            </div>
                            <!--//PRICE END-->
                            
                        </div>                            
                        <!--//HEAD PRICE DETAIL END-->
                        
                        <!--FEATURE LIST START-->
                        <div class="generic_feature_list">
                        	<ul>
                            	<li><span>Unlimited </span> access</li>
                                <li><span>Free </span> high speed internet access</li>
                                <li><span>Individual</span> hot-seat in coworking space</li>
                                <li><span>1 private </span> locker</li>
                                <li><span>30 sheets</span> Support</li>
                            </ul>
                        </div>
                        <!--//FEATURE LIST END-->
                        
                        <!--BUTTON START-->
                        <div class="generic_price_btn clearfix">
                        	<a class="" href="">Sign up</a>
                        </div>
                        <!--//BUTTON END-->
                        
                    </div>
    <!--//PRICE CONTENT END-->
            </div>	
            <!--//BLOCK ROW END-->
            
        </div>

			
            
       
        
	<footer>
    	
</div>
			
			<!-- Social section -->
			<section id="social" class="parallax">
				<div class="overlay">
					<div class="container">
						<div class="row">
						
							<div class="sec-title text-center white wow animated fadeInDown">
								<h2>FOLLOW US</h2>
								<p>Our Social Media</p>
							</div>
							
							<ul class="social-button">
								<li class="wow animated zoomIn"><a href="#"><i class="fa fa-thumbs-up fa-2x"></i></a></li>	
								<li class="wow animated zoomIn"><a href="#"><i class="fab fa-instagram fa-2x"></i></a></li>	
								<li class="wow animated zoomIn"><a href="#"><i class="fab fa-twitter-square fa-2x"></i></a></li>			
							</ul>
							
						</div>
					</div>
				</div>
			</section>
			<!-- end Social section -->
			
			<!-- Contact section -->
			<section id="contact" >
				<div class="container">
					<div class="row">
						
						<div class="sec-title text-center wow animated fadeInDown">
							<h2>Contact</h2>
							<p>Leave a Message</p>
						</div>
						
						
						<div class="col-md-7 contact-form wow animated fadeInLeft">
							<form action="#" method="post" style="margin: 0 0 30px;">
								<div class="input-field">
									<input type="text" name="name" class="form-control" placeholder="Your Name...">
								</div>
								<div class="input-field">
									<input type="email" name="email" class="form-control" placeholder="Your Email...">
								</div>
								<div class="input-field">
									<input type="text" name="subject" class="form-control" placeholder="Subject...">
								</div>
								<div class="input-field">
									<textarea name="message" class="form-control" placeholder="Messages..."></textarea>
								</div>
						       	<button type="submit" id="submit" class="btn btn-blue btn-effect">Send</button>
							</form>
						</div>
						
						<div class="col-md-5 wow animated fadeInRight">
							<address class="contact-details">
								<h3>Contact Us</h3>						
								<p><i class="fa fa-pencil"></i>Jl.Cisitu Indah 6 27-6,<span>Dago</span> <span>Kecamatan Coblong, Kota Bandung, Jawa Barat </span><span>40135</span></p><br>
								<p><i class="fas fa-mobile-alt"></i>Phone:+6281222771703</p>
								<p><i class="fa fa-envelope"></i>cocreative@gmail.com</p>
							</address>
						</div>
			
					</div>
				</div>
			</section>
			<!-- end Contact section -->
			
			<!-- <section id="google-map">
				<div id="map-canvas" class="wow animated fadeInUp"></div>
			</section> -->
		
		</main>
		<div class="g-map">

		<div id="googleMap" style="width:100%;height:450PX;"></div>
		</div>
		<footer id="footer">
			<div class="container">
				<div class="row text-center">
					<div class="footer-content">
						<div class="wow animated fadeInDown">
							<p>newsletter signup</p>
							<p>Get Cool Stuff! We hate spam!</p>
						</div>
						<form action="#" method="post" class="subscribe-form wow animated fadeInUp">
							<div class="input-field">
								<input type="email" class="subscribe form-control" placeholder="Enter Your Email...">
								<button type="submit" class="submit-icon">
									<i class="fa fa-paper-plane fa-lg"></i>
								</button>
							</div>
						</form>
						<!-- <div class="footer-social">
							<ul>
								<li class="wow animated zoomIn"><a href="#"><i class="fa fa-thumbs-up fa-3x"></i></a></li>
								<li class="wow animated zoomIn" data-wow-delay="0.3s"><a href="#"><i class="fa fa-twitter fa-3x"></i></a></li>
								<li class="wow animated zoomIn" data-wow-delay="0.6s"><a href="#"><i class="fa fa-skype fa-3x"></i></a></li>
								<li class="wow animated zoomIn" data-wow-delay="0.9s"><a href="#"><i class="fa fa-dribbble fa-3x"></i></a></li>
								<li class="wow animated zoomIn" data-wow-delay="1.2s"><a href="#"><i class="fa fa-youtube fa-3x"></i></a></li>
							</ul>
						</div> -->
						
						<p>Copyright &copy; 2018 Design and Developed By <a href="http://www.themefisher.com">Themefisher</a> 
						</p>
					</div>
				</div>
			</div>
		</footer>


		
			
		
		<!-- Essential jQuery Plugins
		================================================== -->
		<!-- Main jQuery -->
        <script src="js/jquery-1.11.1.min.js"></script>
		<!-- Twitter Bootstrap -->
        <script src="js/bootstrap.min.js"></script>
		<!-- Single Page Nav -->
        <script src="js/jquery.singlePageNav.min.js"></script>
		<!-- jquery.fancybox.pack -->
        <script src="js/jquery.fancybox.pack.js"></script>
		<!-- Google Map API -->
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAnxnh_pgnqVwKiuPKkuATbIFXP14yggOI"></script>

		<!-- <script src="http://maps.google.com/maps/api/js?sensor=false"></script>  -->
		<!-- Owl Carousel -->
        <script src="js/owl.carousel.min.js"></script>
        <!-- jquery easing -->
        <script src="js/jquery.easing.min.js"></script>
        <!-- Fullscreen slider -->
        <script src="js/jquery.slitslider.js"></script>
        <script src="js/jquery.ba-cond.min.js"></script>
		<!-- onscroll animation -->
        <script src="js/wow.min.js"></script>
		<!-- Custom Functions -->
        <script src="js/main.js"></script>
        <script src="https://kit.fontawesome.com/f62a47ce2e.js"></script>

       
    </body>
</html>
